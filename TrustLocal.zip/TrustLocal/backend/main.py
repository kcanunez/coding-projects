from fastapi import FastAPI
from backend.routes import business, user

app = FastAPI(title="TrustLocal API")

# Register routers
app.include_router(user.router, prefix="/api/user", tags=["User"])
app.include_router(business.router, prefix="/api/business", tags=["Business"])

@app.get("/")
def home():
    return {"message": "Welcome to TrustLocal API"}
