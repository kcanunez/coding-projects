from pydantic import BaseModel, Field
from typing import List, Optional

class Review(BaseModel):
    user: str  
    rating: float = Field(..., ge=1, le=5)  # Ensure rating is between 1 and 5
    comment: str

class Business(BaseModel):
    name: str
    location: str
    category: str
    rating: float = 0.0  
    reviews: List[Review] = []  

class User(BaseModel):
    username: str
    email: str
    password: str
