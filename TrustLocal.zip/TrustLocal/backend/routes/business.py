from fastapi import APIRouter, HTTPException, Depends
from backend.database import db
from backend.models import Business, Review
from bson import ObjectId

router = APIRouter()

# ✅ Create a business
@router.post("/")
def create_business(business: Business):
    if not db:
        raise HTTPException(status_code=500, detail="Database connection failed")
    
    result = db.businesses.insert_one(business.model_dump())
    return {"id": str(result.inserted_id)}

# ✅ List all businesses
@router.get("/")
def list_businesses():
    if not db:
        raise HTTPException(status_code=500, detail="Database connection failed")

    businesses = list(db.businesses.find())
    for business in businesses:
        business["_id"] = str(business["_id"])  # Convert ObjectId to string
    return businesses

# ✅ Get a specific business
@router.get("/{business_id}")
def get_business(business_id: str):
    if not db:
        raise HTTPException(status_code=500, detail="Database connection failed")

    try:
        business = db.businesses.find_one({"_id": ObjectId(business_id)})
        if not business:
            raise HTTPException(status_code=404, detail="Business not found")
        business["_id"] = str(business["_id"])
        return business
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ✅ Add a review to a business
@router.post("/{business_id}/review")
def add_review(business_id: str, review: Review):
    if not db:
        raise HTTPException(status_code=500, detail="Database connection failed")

    try:
        business = db.businesses.find_one({"_id": ObjectId(business_id)})
        if not business:
            raise HTTPException(status_code=404, detail="Business not found")

        business["reviews"].append(review.model_dump())

        # Recalculate average rating
        total_rating = sum([r["rating"] for r in business["reviews"]])
        business["rating"] = total_rating / len(business["reviews"])

        db.businesses.update_one({"_id": ObjectId(business_id)}, {"$set": business})
        return {"message": "Review added successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
