from fastapi import APIRouter, HTTPException
from backend.database import db
from backend.models import User
from bson import ObjectId

router = APIRouter()

# ✅ Create a user
@router.post("/")
def create_user(user: User):
    if not db:
        raise HTTPException(status_code=500, detail="Database connection failed")

    existing_user = db.users.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    result = db.users.insert_one(user.model_dump())  
    return {"id": str(result.inserted_id)}

# ✅ List all users
@router.get("/")
def list_users():
    if not db:
        raise HTTPException(status_code=500, detail="Database connection failed")

    users = list(db.users.find())
    for user in users:
        user["_id"] = str(user["_id"])  
    return users
