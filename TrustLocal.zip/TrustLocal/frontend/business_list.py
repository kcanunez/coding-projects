import flet as ft
import requests

API_URL = "http://127.0.0.1:8000/api/business"  # Ensure your backend is running

def fetch_businesses():
    try:
        response = requests.get(API_URL)
        if response.status_code == 200:
            return response.json() or []  # Return empty list if no data
        else:
            print(f"Error: Received status code {response.status_code}")
            return []
    except Exception as e:
        print("Error fetching businesses:", e)
        return []

def business_list_view(page: ft.Page):
    page.title = "Business Listings"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER  # Center horizontally
    page.vertical_alignment = ft.MainAxisAlignment.CENTER  # Center vertically

    businesses = fetch_businesses()

    content = []
    
    if not businesses:
        content.append(
            ft.Text("No businesses found.", size=18, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER)
        )
    else:
        for business in businesses:
            card = ft.Card(
                content=ft.Container(
                    ft.Column([
                        ft.Text(f"📌 {business.get('name', 'Unnamed Business')}", size=20, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                        ft.Text(f"📍 {business.get('location', 'Unknown Location')}", size=16, text_align=ft.TextAlign.CENTER),
                        ft.Text(f"⭐ {business.get('rating', 'N/A')} / 5", size=14, text_align=ft.TextAlign.CENTER)
                    ], spacing=10, alignment=ft.MainAxisAlignment.CENTER),  # Center text inside cards
                    padding=15,
                    alignment=ft.alignment.center  # Center cards inside container
                ),
                elevation=4,  # Slight shadow effect
            )
            content.append(card)

    page.add(
        ft.Container(
            ft.Column(
                content,
                spacing=20,
                alignment=ft.MainAxisAlignment.CENTER,  # Center items vertically
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,  # Center items horizontally
            ),
            alignment=ft.alignment.center,  # Fully center everything
        )
    )
    page.update()

if __name__ == "__main__":
    ft.app(target=business_list_view)
