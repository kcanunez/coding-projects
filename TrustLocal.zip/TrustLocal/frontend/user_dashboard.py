import flet as ft

def user_dashboard(page: ft.Page):
    page.title = "User Dashboard"
    page.padding = 20
    page.theme_mode = "light"

    def show_section(e):
        selected = e.control.data
        content.controls.clear()

        if selected == "User Management":
            content.controls.append(ft.Text("👤 User Profile", size=24, weight=ft.FontWeight.BOLD))

            profile_section = ft.Container(
                content=ft.Row([
                    # CircleAvatar on the left
                    ft.CircleAvatar(
                        content=ft.Icon(ft.icons.PERSON, size=50),
                        radius=40,  # Adjust size as needed
                        bgcolor=ft.colors.BLUE_100  # Background color
                    ),
                    # Profile details on the right
                    ft.Column([
                        ft.Text("Name: John Doe", size=16, weight=ft.FontWeight.BOLD),
                        ft.Text("Email: johndoe@example.com", size=14),
                        ft.Text("Phone: (555) 123-4567", size=14),
                        ft.ElevatedButton("Edit Profile", icon=ft.icons.EDIT)
                    ], spacing=5, alignment=ft.MainAxisAlignment.START)
                ], spacing=20, alignment=ft.MainAxisAlignment.START),
                padding=15,
                border_radius=10,
                bgcolor=ft.colors.BLUE_50,
                expand=True
            )

            content.controls.append(profile_section)
            content.controls.append(
            ft.Container(
                content=ft.Text("📝 Your Reviews", size=24, weight=ft.FontWeight.BOLD),
                padding=ft.padding.only(top=20)
            )
        )


            review_management_section = ft.Column(
                controls=[
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Review for Local Café", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Great coffee and ambiance!", size=14),
                                ],
                                spacing=2,  # Tight spacing
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Forces left & right layout
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,  # Aligns text & icons
                    ),
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Review for Book Haven", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Excellent collection of books!", size=14),
                                ],
                                spacing=2,
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Review for TechFix Solutions", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Great Customer Service! 5 Stars Indeed!", size=14),
                                ],
                                spacing=2,  # Tight spacing
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Forces left & right layout
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,  # Aligns text & icons
                    ),
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Green Leaf Cafe", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Loved the Coffee and the ambiance!", size=14),
                                ],
                                spacing=2,  # Tight spacing
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Forces left & right layout
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,  # Aligns text & icons
                    ),
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Review for Artisan Bakery", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Superb pastries and bread!", size=14),
                                ],
                                spacing=2,  # Tight spacing
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Forces left & right layout
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,  # Aligns text & icons
                    ),
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Review for City Gym", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Nice place and great equipment!", size=14),
                                ],
                                spacing=2,  # Tight spacing
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Forces left & right layout
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,  # Aligns text & icons
                    ),
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Review for FastFix Repairs", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Excellent Customer Service!", size=14),
                                ],
                                spacing=2,  # Tight spacing
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Forces left & right layout
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,  # Aligns text & icons
                    ),
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text("Review for Cozy Pet Store", size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text("Loved their equipment and treats for Animals!", size=14),
                                ],
                                spacing=2,  # Tight spacing
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT, tooltip="Edit Review"),
                                    ft.IconButton(ft.icons.DELETE, tooltip="Delete Review"),
                                ],
                                spacing=5,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,  # Forces left & right layout
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,  # Aligns text & icons
                    ),
                ],
                spacing=10,  # Space between reviews
            )

            content.controls.append(review_management_section)

            

        elif selected == "Saved Businesses":
            content.controls.append(ft.Text("⭐ Your Saved Businesses", size=24, weight=ft.FontWeight.BOLD))
            
            business_rows = [
                ft.Row([
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: Local Café", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 123 Main St"),
                            ft.Text("⭐ Rating: 4.5/5"),
                            ft.Text("📞 Contact: (555) 123-4567"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: Book Haven", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 456 Elm St"),
                            ft.Text("⭐ Rating: 4.8/5"),
                            ft.Text("📞 Contact: (555) 987-6543"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                ], spacing=10),

                ft.Row([
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: TechFix Solutions", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 789 Oak St"),
                            ft.Text("⭐ Rating: 4.7/5"),
                            ft.Text("📞 Contact: (555) 654-3210"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: Green Leaf Market", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 101 Pine St"),
                            ft.Text("⭐ Rating: 4.6/5"),
                            ft.Text("📞 Contact: (555) 321-9876"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                ], spacing=10),

                ft.Row([
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: Artisan Bakery", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 202 Maple St"),
                            ft.Text("⭐ Rating: 4.9/5"),
                            ft.Text("📞 Contact: (555) 111-2222"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: City Gym", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 303 Birch St"),
                            ft.Text("⭐ Rating: 4.3/5"),
                            ft.Text("📞 Contact: (555) 333-4444"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                ], spacing=10),

                ft.Row([
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: FastFix Repairs", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 404 Cedar St"),
                            ft.Text("⭐ Rating: 4.2/5"),
                            ft.Text("📞 Contact: (555) 555-6666"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Business Name: Cozy Pet Store", size=18, weight=ft.FontWeight.BOLD),
                            ft.Text("📍 Location: 505 Walnut St"),
                            ft.Text("⭐ Rating: 4.8/5"),
                            ft.Text("📞 Contact: (555) 777-8888"),
                        ], spacing=5),
                        padding=10,
                        border_radius=10,
                        bgcolor=ft.colors.GREEN_100,
                        expand=True
                    ),
                ], spacing=10),
            ]

            for row in business_rows:
                content.controls.append(row)
        

        elif selected == "Review Management":
            content.controls.append(ft.Text("📝 Your Reviews", size=24, weight=ft.FontWeight.BOLD))
            
            review_form = ft.Column([
                ft.Text("Select a Business:"),
                ft.Dropdown(
                    options=[
                        ft.dropdown.Option("Local Café"),
                        ft.dropdown.Option("Book Haven"),
                        ft.dropdown.Option("TechFix Solutions"),
                        ft.dropdown.Option("Green Leaf Market"),
                        ft.dropdown.Option("Artisan Bakery"),
                        ft.dropdown.Option("City Gym"),
                        ft.dropdown.Option("FastFix Repairs"),
                        ft.dropdown.Option("Cozy Pet Store"),
                    ]
                ),
                ft.Text("Write Your Review:"),
    ft.TextField(multiline=True, height=50),
    ft.Text("Rate this Business (1-5 Stars):"),
    ft.Slider(min=1, max=5, divisions=4, label="{value} Stars"),
    ft.Row([  # Centering the button
        ft.ElevatedButton("Submit Review")
    ], alignment=ft.MainAxisAlignment.CENTER)
], spacing=10)
            content.controls.append(review_form)

        elif selected == "Settings":
            content.controls.append(ft.Text("⚙️ Account Settings", size=24, weight=ft.FontWeight.BOLD))
            account_settings_section = ft.Column([
                    ft.TextField(label="Update Email", hint_text="Enter new email"),
                    ft.TextField(label="Change Password", hint_text="Enter new password", password=True),
                    ft.TextField(label="Confirm Password", hint_text="Re-enter new password", password=True),
                    ft.Switch(label="Enable Notifications"),
                    ft.Container(
            content=ft.ElevatedButton("Save Changes", icon=ft.icons.SAVE),
            alignment=ft.alignment.center  # Centers the button horizontally
        )
    ], spacing=10)


            content.controls.append(account_settings_section)

        page.update()

    welcome_text = ft.Container(
    content=ft.Text(
        "Welcome to TrustLocal: A Local Business Directory and Review System!", 
        size=28, 
        weight=ft.FontWeight.BOLD, 
        text_align=ft.TextAlign.CENTER
    ),
    alignment=ft.alignment.center,  # Centers the text container
    expand=True  # Allows it to take up available space
)
    headers = ft.Row([
        ft.ElevatedButton("👤 User Management", data="User Management", on_click=show_section, bgcolor=ft.colors.BLUE_100, color=ft.colors.BLACK, expand=True),
        ft.ElevatedButton("⭐ Saved Businesses", data="Saved Businesses", on_click=show_section, bgcolor=ft.colors.GREEN_100, color=ft.colors.BLACK, expand=True),
        ft.ElevatedButton("📝 Review Management", data="Review Management", on_click=show_section, bgcolor=ft.colors.YELLOW_100, color=ft.colors.BLACK, expand=True),
        ft.ElevatedButton("⚙️ Settings", data="Settings", on_click=show_section, bgcolor=ft.colors.RED_100, color=ft.colors.BLACK, expand=True),
    ], spacing=5, alignment=ft.MainAxisAlignment.CENTER)

    content = ft.Column([
        ft.Text("Select a section above", size=20, italic=True)
    ], alignment=ft.MainAxisAlignment.CENTER)

    main_layout = ft.Column([
        welcome_text, headers, content
    ], spacing=20, alignment=ft.MainAxisAlignment.CENTER)

    page.add(main_layout)

if __name__ == "__main__":
    ft.app(target=user_dashboard)
